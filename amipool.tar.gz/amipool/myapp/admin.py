from django.contrib import admin
from myapp.models import Publisher, Author

admin.site.register(Publisher)
admin.site.register(Author)
